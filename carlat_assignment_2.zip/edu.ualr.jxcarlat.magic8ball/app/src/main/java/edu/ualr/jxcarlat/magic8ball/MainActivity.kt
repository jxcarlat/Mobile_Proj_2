package edu.ualr.jxcarlat.magic8ball

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import java.lang.Math.abs
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.system.measureTimeMillis


class MainActivity : AppCompatActivity(), SensorEventListener {
    //We create our string array which will output to the user the app's prediction
    var myStrings: Array<String> = arrayOf(
            "It is certain", "You may rely on it",
            "Reply hazy, try again", "Ask again later",
            "Better not tell you now", "My reply is no",
            "Outlook not so good", "Very doubtful",
            "Most likely", "Yes - definitely"
    )
    //Initialize all variables that will be modified for future use as well as getting our
    //accelerometer primed
    var mySensorManager: SensorManager? = null
    var myAccelerometer: Sensor? = null
    var mSpeed: Double = 0.0
    var mSpeedCurrent: Double = 0.0
    var mSpeedLast: Double = 0.0
    var mGravity = FloatArray(3)
    var lastX = 0.0
    var lastY = 0.0
    var lastZ = 0.0
    var lastTime: Long = 0
    var indexPoint: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //In our onCreate method we grab our accelerometer and will use it in the future
        //in our onSensorChanged method
        mySensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        myAccelerometer = mySensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)





    }
    override fun onSaveInstanceState(outState: Bundle?){
        //onSaveInstanceState helps us survive the os from killing the app
        //We save the last instance of our text output and put it into our bundle
        //by using outState and putting the char sequence in.
        super.onSaveInstanceState(outState)
        val predictionText: TextView =
                findViewById(R.id.textView)
        val pText = predictionText.text
        outState?.putCharSequence("savedText", pText)

    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle?){
        //onRestoreInstanceState helps us survive the os from killing the app
        //This will restore our instance state by grabbing the saved text from
        //onSaveInstanceState and restore it by putting it back in our textView.
        super.onRestoreInstanceState(savedInstanceState)
        val predictionText: TextView =
                findViewById(R.id.textView)
        val pText = savedInstanceState?.getCharSequence("savedText")
        predictionText.setText(pText)
    }
    override fun onResume(){
        super.onResume()
        //When our user Resumes the game we keep our previous state and also start the accelerometer
        //up again
        mySensorManager!!.registerListener(this, myAccelerometer, SensorManager.SENSOR_DELAY_UI)
    }

    override fun onPause(){
        super.onPause()
        //When the user puts the app in the background we turn the accelerometer off so it doesn't
        //use battery in the background
        mySensorManager!!.unregisterListener(this)
    }
    override fun onSensorChanged(event: SensorEvent?) {
        // This is the function that will be updated every time our
        // accelerometer sends an update to our app

        val currentTime: Long = System.currentTimeMillis()
        Log.d("My log", currentTime.toString())
        //If our accelerometer is up and running
        if (event!!.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            //We run through our shake operation every millisecond or so giving us plenty of time
            //between shakes so that it's not constantly updating and messing with performance
            if (currentTime - lastTime > 50) {
                //Our gravity will take the x y z values from SensorEvent
                mGravity = event.values.clone()
                //and assign them to our x y z values
                val x = mGravity[0].toDouble()
                val y = mGravity[1].toDouble()
                val z = mGravity[2].toDouble()
                //On our next go around mSpeedLast will be assigned mSpeedCurrent's value
                mSpeedLast = mSpeedCurrent
                //Assign mSpeedCurrent to the absolute value of x y z subtracted by their
                //last states (distance formula)
                mSpeedCurrent = abs(x  + y  + z  - lastX - lastY - lastZ)
                //Make our delta value mSpeedCurrent subtracted by mSpeedLast
                val positionDelta = mSpeedCurrent - mSpeedLast
                //mSpeed will be assigned itself multiplied by gravity and added with the
                //delta value
                mSpeed = mSpeed * 0.9f + positionDelta
                //If our speed is greater than 12 at any point than we consider
                //this a shake
                if (mSpeed > 12) {
                    //So we generate a random integer to put in our string array

                    fun ClosedRange<Int>.random() =
                            Random().nextInt((endInclusive + 1) - start) + start
                    //Assign indexPoint with our random integer
                    indexPoint = (0..9).random()
                    //And implement it in our text array myStrings and assign whatever
                    //string it happens to be to our TextView predictionText.
                    val predictionText: TextView =
                            findViewById(R.id.textView)
                    predictionText.text = myStrings[indexPoint]
                }
                //update last variable with the current x y z values for next go around.
                lastX = x
                lastY = y
                lastZ = z
                //Update lastTime by assigning in currentTime
                lastTime = currentTime

            }



        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        //We include onAccuracyChanged as a required default
    }
}